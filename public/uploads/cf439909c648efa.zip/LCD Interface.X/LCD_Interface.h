/* 
 * File:   LCD_Interface.h
 * Author: karthik
 *
 * Created on April 4, 2016, 1:35 PM
 */

#ifndef LCD_INTERFACE_H
#define	LCD_INTERFACE_H

void LCD_delay_ms (int delay);
void LCD_delay_us (int delay);
void LCD_cmd (char cmd);
void LCD_data (char data);
void LCD_data_string(char* string);
void LCD_move_cursor(char line);
void LCD_Init(void);


#endif	/* LCD_INTERFACE_H */

