/* 
 * File:   LCD_Interface.c
 * Author: karthik
 *
 * 
 */

#include <stdio.h>
#include <string.h>
#include "Configuration.h"	 
#include "LCD_Interface.h"

#define LCD_Enable  PORTCbits.RC7
#define LCD_RW      PORTCbits.RC6
#define LCD_RS      PORTCbits.RC5
#define LCD_Data    PORTD
#define LCD_row     2
#define LCD_col     16

void LCD_delay_ms(int delay)
{
    int count = (delay*1000)/15;
    while(--count != 0)
    continue;
}

void LCD_delay_us(int delay)
{
    int count = (delay)/15;
    while(--count != 0)
    continue;
}

void LCD_cmd (char cmd)
{
    LCD_Data = cmd;
    LCD_RS = 0;
    LCD_RW = 0;
    LCD_Enable = 1;
    LCD_delay_us(10);
    LCD_Enable = 0;
    LCD_delay_ms(1);
    
}

void LCD_data (char data)
{
     LCD_Data = data;
     LCD_RS = 1;
     LCD_RW = 0;
     LCD_Enable = 1;
     LCD_delay_us(10);
     LCD_Enable = 0;
     LCD_delay_ms(1);
    
}

void LCD_data_string(char* string)
{
    int index;
    for(index =0;index<16;index++)
    {
        if(string[index] == '\0')
            break;
        LCD_data(string[index]);
    }
}

void LCD_move_cursor (char line)
{
    char addr;
    if(line == 1)
        addr = 0x80;
    else
        addr = 0xc0;
    LCD_cmd (addr);
    
}
   

void LCD_Init(void)
{
    TRISC = 0;       // Port Output for control pins
    TRISD = 0;       // Port output for Data pins
    LCD_delay_ms (5);
    LCD_cmd (0x38);   // 8 bit mode, 5*7 matrix with 2 line
    LCD_cmd (0x0E);   // Display and cursor ON
    LCD_cmd (0x01);   // clear LCD
    LCD_cmd (0x80);   // Move cursor to first line
    
}



