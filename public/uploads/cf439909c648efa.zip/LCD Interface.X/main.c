/* 
 * File:   main.c
 * Author: karthikPC
 *
 * Created on April 4, 2016, 2:16 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include "LCD_Interface.h"

void main()
{
    LCD_Init();
    LCD_data_string("Hello World !!");
    LCD_move_cursor(2);
    LCD_data_string ("** mcuhq **");
    while(1);
}