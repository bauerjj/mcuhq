/* 
 * File:   main.c
 * Author: mack
 *
 * Created on February 2, 2016, 5:07 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
void main(void) {
    //main function
OSCILLATOR_Initialize();
PIN_MANAGER_Initialize();
TMR2_Initialize();
PWM3_Initialize();

//Write your code here

}

