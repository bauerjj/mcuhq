/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/Grace.h>

/*
 *  ======== main ========
 */
int main(void)
{
    Grace_init();                   // Activate Grace-generated configuration
    
    P1DIR = BIT6; // Green LED as output
    P1OUT = BIT6; // Turn ON the LED

    __bis_SR_register(LPM0_bits);

    return (0);
}
