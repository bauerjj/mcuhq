
#include "GSM.h"
#include "UART.h"
#include "delay.h"

int main()
{
  char SmsText[20]={0}; // will be used to store the received SMS text. Make the array size 1 chracter more than the SMS size to allow for the nul character 
  char SenderNumber[14]={0}; // will be used to store the sending number. Make the array size 1 chracter more than the number size to allow for the nul character 
  UART_Init();
  GSM_Init();
  char i=0;
  while (1)
  {
    
    //Set the receiving arrays members to Zeros
    i=0;
    while (*(SmsText+i)!='\0' || *(SenderNumber+i)!='\0')
    {
      *(SmsText+i)=0;
      *(SenderNumber+i)=0;
    }
    
    SMSReceive(SmsText,SenderNumber);
    delay_ms(1000);
    SMSSend(SenderNumber,SmsText);
    
  }
  
}
