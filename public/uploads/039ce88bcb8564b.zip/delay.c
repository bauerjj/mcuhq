#include "delay.h"
#include "TM4C123GH6PM.h"

#define get_bit(reg,bitnum) ((reg & (1<<bitnum))>>bitnum) // Macro used to get the value of a certain bit in a register

void delay_ms (int time_ms) // Delay function using the timer. the input to the function is the required delay in milliseconds
{
  SYSCTL->RCGCTIMER=0x01;
  TIMER0->ICR|=(1<<0);
  TIMER0->CTL=0x00;
  TIMER0->CFG=0x00; //A timer is enabled
  TIMER0->TAMR=0x01; //0x01-> one-shot timer mode
  TIMER0->TAILR=(16000000UL/1000)*time_ms;
  TIMER0->CTL|=(1<<0);
  while (get_bit(TIMER0->RIS,0)==0)
  {}
}