#include "TM4C123GH6PM.h"
#include "UART.h"

#define get_bit(reg,bitnum) ((reg & (1<<bitnum))>>bitnum) // Macro used to get the value of a certain bit in a register

void UART_Init (void)
{
  SYSCTL->RCGCUART|=(1<<1); //Enable and provide clock UART Module 1
  SYSCTL->RCGCGPIO |=(1<<1) ;//Enable and provide clock to Port B
  GPIOB->AFSEL|=(1<<0)|(1<<1); //Enable Alternate function for Pins 0& 1 of Port B
  GPIOB->PCTL|=(1<<0)|(1<<4); //Choose UART as the alternate function for Pins 0& 1 of Port B
  GPIOB->DEN|=(1<<0)|(1<<1); // Enable Digital functionality for Pins 0& 1 of Port B
  UART1->CTL &=~(1<<0); // Disable UART protocol
  UART1->IBRD=104; //Write the UARTIBRD value for the Baud Rate (Assuming Baud rate of 9600)
  UART1->FBRD= 11; //Write the UARTFBRD value for the Baud Rate (Assuming Baud rate of 9600)
  UART1->LCRH=0x60; //Set bits 5&6 to indicate a word length of 8 bits and clear all the other bits of the UARTLCRH register
  UART1->CC= 0x00; // Choose System clock as the UART Clock Source
  UART1->CTL=0x301; //Write bit values to the UARTCTL register as clarified in step 6.  
}

void UART_SendChar (char data)
{
  while (get_bit(UART1->FR,5)==1)  //Poll on bit 5 (TXFF) until it becomes 0. The loop exits only if the bit value is 0
  {
  }
  UART1->DR=data; // Put the data to send in the UARTDR register
}


void UART_SendStr (char* string) // Input to the function is a pointer to the string start point in the memory.
{
  char i=0;
  while (*(string+i) != '\0')
  {
    UART_SendChar(*(string+i));
    i+=1;
  }
}

void UART_RecChar (char* data) //Input to the function is a pointer to a memory place to save the received data in
{
  while (get_bit(UART1->FR,4)==1) //Poll on bit 4 (RXFE) until it becomes 0. The loop exits only if the bit value is 0
  {}
  *data=UART1->DR; // Read the UARTDR which contains the received data to the pointer provided by the function user.
}

void UART_RecCharwTimeOut (char* data)
{
  int count=(UARTRecTimeOut*(UARTSysClock/1000))/3; // divided by 3 as the decrement takes 3 clock ticks
  while (get_bit(UART1->FR,4)==1&&count>0)
  {
    count--;
  }
  if(count==0)
  {
    *data='\0';
  }
  else
  {*data=UART1->DR;}
}