#include "GSM.h"
#include "UART.h"
#include "delay.h"

char AT_Response (char *ATRes) //*ATRes is a pointer to the start of the array where the response will be stored.
{
  char i=0; 
  char ok=0;
  while (*(ATRes)=='\0')
  {
    do 
    {
      UART_RecCharwTimeOut(ATRes+i); // Rceive character using the UART_RecCharwTimeOut function and place it in tha array
      i++;
    }
    while(*(ATRes+i-1)!='\0'); // when nothing is receveived by UART_RecCharwTimeOut, a null is returned and saved in the array. 
    
  }
  
  i=0; //reset the array index to 0
  while (*(ATRes+i)!='\0')       // This loop searches for the word "OK" in the AT command response
  {
    if (*(ATRes+i)=='O' && *(ATRes+i+1)=='K' )
    {
      ok=1; // if "OK" is found, the variable named ok will be set to 1 otherwise it will stay 0.
      break;
    }
    i++;
  }
  return ok;    //OK variable is returned by the function
}

void GSM_Init(void)
{
  //Synchronization as the GSM module is on auto bauding
  char confirm=0; // Will be used to store the return value of the AT_Response function
  char ATResponse[8]={0}; // will be used to store the AT command response that is also coming for the AT_Response function
  char ATEResponse[8]={0}; // will be used to store the ATE0 command response
  char trial=1; //Will be used to count the number of trials to send the AT command and successfully receive an "OK" response.
  
  while (confirm==0 && trial<=3) // a Maximum of 3 trials is allowed, then the function exits.
  {
    UART_SendStr ("AT\n \r"); // Send "AT" Command
    confirm=AT_Response(ATResponse); // Receive the response and write it to ATResponse array. The function return value is stored in the variable "confirm"
    trial++; //Increment the number of trials
    
  }
  delay_ms (500); //Allow a delay of 500 ms before send ing the next command
  confirm=0;trial=1; // reset the values of confirm and trial
  while (confirm==0 && trial<=3) // a Maximum of 3 trials is allowed, then the function exits.
  {
    UART_SendStr ("ATE0\n \r"); // Send "ATE0" Command
    confirm=AT_Response(ATEResponse); // Receive the response and write it to ATEResponse array. The function return value is stored in the variable "confirm"
    trial++; //Increment the number of trials
    
  }
  delay_ms (500);
}

void SMSReceive (char* SMSReturn, char* Sender)
{
  char SmsNotification[17]={0}; // Will be used to store the CMTI message
  char SmsText[110]={0}; // Will be used to store the Sms content
  char MemoryType[5]={0}; // Will be used to store th memory type
  char MessageIndex[6]={0}; // Will be used to store the message index
  char i=0; // Will be used as an array index 
  char j=0; // Will be used as an array index
  char SmSReceived=0;  // Will be used to indicate that a new SMS arrived
  while (SmSReceived==0)  // This is an infinite loop that exits only if an SMS is received
  {
    i=0;
    do // This loop receives the CMTI message characters one by one and save it to SmsNotification
    {
      UART_RecCharwTimeOut(SmsNotification+i);
      i++;
    }
    while(*(SmsNotification+i-1)!='\0');  
    if (*(SmsNotification+10)!='\0' && *(SmsNotification+11)!='\0' ) // Check that the message type (Charcters 10 and 11) exists in the message
    {
      SmSReceived=1; // If Message type exists, then CMTI message is received. Set SmSReceived to 1 to exit the loop.
    }
  }
  *(MemoryType)=*(SmsNotification+9);  // Save the memory type characters to MemoryType Array
  *(MemoryType+1)=*(SmsNotification+10);
  *(MemoryType+2)=*(SmsNotification+11);
  *(MemoryType+3)=*(SmsNotification+12);
  *(MemoryType+4)='\0'; // To terminate the string
  
  i=0;
  while (*(SmsNotification+14+i)!='\r') // This loop gets the message index (starting at Charcter 14) and saves it to MessageIndex
  {
    *(MessageIndex+i) = *(SmsNotification+14+i);
    i++;
  }
  
  
  UART_SendStr("AT+CMGF=1;+CPMS="); //Start sending the AT Command
  UART_SendStr (MemoryType);
  UART_SendStr (";+CMGR=");
  UART_SendStr (MessageIndex);
  UART_SendStr ("\n\r");
  
  i=0;
  
  do // Receive the AT commands Response that contains the SMS Text
  {
    UART_RecCharwTimeOut(SmsText+i);
    i++;
  }
  while(*(SmsText+i-1)!='\0');
  
  i=0; // Reset index to 0
  j=0; // Reset index to 0
  
  do //This loop Saerches for the 4th '\n' Character. When found its poistion index will be in i variable
  {
    if (*(SmsText+i)=='\n')
    {
      j++;
    }
    i++;
  }
  while (j<4);
  
  j=0; // Reset index to 0
  while (*(SmsText+i)!='\r') // This loop transfers the characters from the local array SmsText to the user array SMSReturn
  {
    *(SMSReturn+j)=*(SmsText+i);
    j++;
    i++;
  }
  
  
  
  i=0; // Reset index to 0
  j=0; // Reset index to 0
  
  do //This loop Saerches for the 3rd '+' Character. When found its poistion index will be in i variable
  {
    if (*(SmsText+i)=='+')
    {
      j++;
    }
    i++;
  }
  while (j<3);
  
  j=0; // Reset index to 0
  while (*(SmsText+i)!='"') // This loop transfers the characters from the local array SmsText to the user array SMSReturn
  {
    *(Sender+j)=*(SmsText+i);
    j++;
    i++;
  } 
  
  //Delete the SMS
  UART_SendStr ("AT+CMGD=");
  UART_SendStr (MessageIndex);
  UART_SendStr ("\n\r");
  
}

void SMSSend(char *Number, char *Text) // Number is a pointer to an array that holds the mobile number. While Text holds the SMS Text
{
  
  char CMGSResponse[25]={0}; // will be used to store the response of "AT+CMGS".
  char CMGFResponse[7]={0}; // will be used to store the response of "AT+CMGF".
  char SendingResponse [70]={0}; // will be used to store the response after sending the SMS.
  char confirm=0; // will be used to store the returned ok value from AT_Response function.
  Number++;
  UART_SendStr ("AT+CMGF=1"); // send (AT+CMGF Command)
  UART_SendStr ("\n \r");
  confirm=AT_Response (CMGFResponse);
  delay_ms(500); //Allow a delay of 500 ms between commands not to rush the module.
  
  UART_SendStr ("AT+CMGS="); // send (AT+CMGs Command)
  UART_SendChar ('"');
  UART_SendStr(Number);
  
  UART_SendChar ('"');
  UART_SendStr ("\n \r");
  
  
  confirm=AT_Response (CMGSResponse); // Receive response of "AT+CMGS"
  delay_ms(500);
  UART_SendStr(Text); //Send the SMS text
  
  UART_SendChar (0x1A); // Send the SMS terminator
  
  do
  {
    confirm=AT_Response (SendingResponse); //Receive the Response after sending the SMS. (Useful for debugging)
  }
  while (confirm ==0);
  
}
