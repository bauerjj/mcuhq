

char AT_Response (char *ATRes);
void GSM_Init(void);
void SMSReceive (char* SMSReturn, char* Sender);
void SMSSend(char *Number, char *Text);