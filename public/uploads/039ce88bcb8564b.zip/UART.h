

#define UARTSysClock 16000000UL //System Clock
#define UARTRecTimeOut 600 //time in ms after which UART_RcCharwTimeOut function returns. A null is returned if nothing is received.

void UART_Init (void);
void UART_SendChar (char data);
void UART_SendStr (char* string);
void UART_RecChar (char* data);
void UART_RecCharwTimeOut (char* data);