/**
 * Simple program to blink one of the LEDs on the STMF3 discovery board
 * @date June 2016
 * @author mcuhq.com
 */
#include <stdio.h>
#include <stdlib.h>
#include "diag/Trace.h"

#include <stm32f30x.h>
#include <stm32f30x_gpio.h>
#include <stm32f30x_rcc.h>

// Sample pragmas to cope with warnings. Please note the related line at
// the end of this function, used to pop the compiler diagnostics status.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wmissing-declarations"
#pragma GCC diagnostic ignored "-Wreturn-type"

void delay (int a);

void main(int argc, char* argv[])
{
	// At this stage the system clock should have already been configured
	// at high speed.
	GPIO_InitTypeDef gpio;
	SET_BIT(RCC->AHBENR, RCC_AHBENR_GPIOEEN);

	// Configure one of the LEDs as a digital output
	GPIO_StructInit(&gpio);
	gpio.GPIO_Pin = GPIO_Pin_10;
	gpio.GPIO_Mode = GPIO_Mode_OUT;
	gpio.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOE,&gpio);

  // Infinite loop
  while (1)
    {
		GPIO_WriteBit(GPIOE, GPIO_Pin_10,Bit_SET);
	    delay(500000);
		GPIO_WriteBit(GPIOE, GPIO_Pin_10,Bit_RESET);
		delay(500000);
    }
}

void delay (int a)
{
    volatile int i,j;

    for (i=0 ; i < a ; i++)
    {
        j++;
    }

    return;
}

#pragma GCC diagnostic pop

// ----------------------------------------------------------------------------
