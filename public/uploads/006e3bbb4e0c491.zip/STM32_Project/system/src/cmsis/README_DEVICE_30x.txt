The system_stm32f30x.c file is from stsw-stm32108.zip, 
the folder:

	STM32F30x_DSP_StdPeriph_Lib_V1.0.0/Libraries/CMSIS/Device/ST/STM32F30x/Source/Templates

The vectors_stm32f30x.c file was created to conform with the assembly files 
gc_ride7/startup_stm3230x.s.


STM32F37x_DSP_StdPeriph_Lib_V1.0.0/Libraries/CMSIS/Device/ST/STM32F37x/Include
