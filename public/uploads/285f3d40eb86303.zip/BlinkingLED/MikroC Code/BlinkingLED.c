

void main() {
 DDRB.F0=1; // setting up RB0 as output
 DDRB.F1=1;  // setting up RB1 as output
 DDRB.F2=1;   // setting up RB2 as output
 DDRB.F3=1;   // setting up RB3 as output
 DDRB.F4=1;    // setting up RB4 as output


 while(1){
         PORTB.F0=1;
         PORTB.F1=0;
         PORTB.F2=0;
         PORTB.F3=0;
         PORTB.F4=0;
         Delay_ms(500);  // turning ON LED 1 for 500 milisec

         PORTB.F0=0;
         PORTB.F1=1;
         PORTB.F2=0;
         PORTB.F3=0;
         PORTB.F4=0;
         Delay_ms(500);  // turning ON LED 2 for 500 milisec

         PORTB.F0=0;
         PORTB.F1=0;
         PORTB.F2=1;
         PORTB.F3=0;
         PORTB.F4=0;
         Delay_ms(500);  // turning ON LED 3 for 500 milisec

         PORTB.F0=0;
         PORTB.F1=0;
         PORTB.F2=0;
         PORTB.F3=1;
         PORTB.F4=0;
         Delay_ms(500);  // turning ON LED 4 for 500 milisec

         PORTB.F0=0;
         PORTB.F1=0;
         PORTB.F2=0;
         PORTB.F3=0;
         PORTB.F4=1;
         Delay_ms(500);  // turning ON LED 1 for 500 milisec



  }
}