/*
 * uart.h
 *
 *  Created on: Mar 27, 2016
 *      Author: justin
 */

#ifndef UART_H_
#define UART_H_

extern void uartTxByte(unsigned char byte);




#endif /* UART_H_ */
