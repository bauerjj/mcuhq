/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/Grace.h>

/*
 *  ======== main ========
 */
#include <stdint.h>

uint32_t count;

int main(void)
{
    Grace_init();// Activate Grace-generated configuration
    while(1){
    	__delay_cycles(8000); // Short delay of ~8ms
    	count++; // increment counter
    }
    return (0);
}





