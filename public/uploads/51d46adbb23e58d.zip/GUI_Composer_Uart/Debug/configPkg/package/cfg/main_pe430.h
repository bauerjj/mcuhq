/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A65
 */

#include <xdc/std.h>

extern int xdc_runtime_Startup__RESETFXN__C;

extern int xdc_runtime_Startup_reset__I;

extern int xdc_runtime_Startup__EXECFXN__C;

extern int xdc_runtime_Startup_exec__E;

