/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A65
 */

#ifndef xconfig_msp430g2xx3_wdt_toggle_pin__
#define xconfig_msp430g2xx3_wdt_toggle_pin__



#endif /* xconfig_msp430g2xx3_wdt_toggle_pin__ */ 
